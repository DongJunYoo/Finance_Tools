﻿This Package is for Python. 
THis Package contains the followings: 

1. Time Series Plotting of Portfolio Assets 
2. Computing Yearly Log Return of assets and their Covariance 
3. Plotting Potential Portfolios (Efficient Frontier)
4. Optimize Portfolio by 
	a) Max Sharpe Ratio 
	b) Minimum Sharpe Ratio 
5. Normality Test 
	*computes values such as kurtosis, normality test p-value 
6. Q-Q plot for normality test. 

#All assets input should be google finance e.g. stock quote format
